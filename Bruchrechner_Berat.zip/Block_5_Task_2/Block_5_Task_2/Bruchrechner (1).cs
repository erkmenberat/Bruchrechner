﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_Block_4_6
{
    
    public class Bruch
    {

        int zähler, nenner; 
        //public int Zähler { get; set; }
        //public int Nenner { get; set; }
        //public Bruchrechner2 LetztesErgebnis { get; set; }
        public Bruchrechner result;
        // Konstruktor
        public Bruch(int z,  int n)
        {
            zähler = n;
            nenner = z;
            result = new Bruchrechner(z, n);
        }

        // Methoden für arithmetische Operationen



        /// Führt eine Addition von zwei Brüchen durch.
        public Bruchrechner Addition(Bruchrechner b1, Bruchrechner b2)
        {
            int neuerZähler = b1.Zähler * b2.Nenner + b2.Zähler * b1.Nenner;
            int neuerNenner = b1.Nenner * b2.Nenner;
            return result = new Bruchrechner(neuerZähler, neuerNenner);
        }



        /// Führt eine Subtraktion von zwei Brüchen durch.
        public Bruchrechner Subtraktion(Bruchrechner bruch1, Bruchrechner bruch2)
        {
            int neuerZähler = bruch1.Zähler * bruch2.Nenner - bruch2.Zähler * bruch1.Nenner;
            int neuerNenner = bruch1.Nenner * bruch2.Nenner;
            result = new Bruchrechner(neuerZähler, neuerNenner);
            return result;
        }



        /// Führt eine Multiplikation von zwei Brüchen durch.
        public Bruchrechner Multiplikation(Bruchrechner bruch1, Bruchrechner bruch2)
        {
            int neuerZähler = bruch1.Zähler * bruch2.Zähler;
            int neuerNenner = bruch1.Nenner * bruch2.Nenner;
            result = new Bruchrechner(neuerZähler, neuerNenner);
            return result;
        }

        /// Führt eine Division von zwei Brüchen durch.
        public Bruchrechner Division(Bruchrechner bruch1, Bruchrechner bruch2)
        {
            if (bruch2.Zähler == 0)
                throw new ArgumentException("Fehler: Division durch Null");

            int neuerZähler = bruch1.Zähler * bruch2.Nenner;
            int neuerNenner = bruch1.Nenner * bruch2.Zähler;
            result = new Bruchrechner(neuerZähler, neuerNenner);
            return result;
        }

        /// Berechnet die Potenz eines Bruchs.
        public Bruchrechner Potenz(Bruchrechner bruch, int exponent)
        {
            int neuerZähler = (int)Math.Pow(bruch.Zähler, exponent);
            int neuerNenner = (int)Math.Pow(bruch.Nenner, exponent);
            result = new Bruchrechner(neuerZähler, neuerNenner);
            return result;
        }

        /// Berechnet die Quadratwurzel eines Bruchs.

        public Bruchrechner Quadratwurzel(Bruchrechner bruch)
        {
            int neuerZähler = (int)Math.Sqrt(bruch.Zähler);
            int neuerNenner = (int)Math.Sqrt(bruch.Nenner);
            result = new Bruchrechner(neuerZähler, neuerNenner);
            return result;
        }

        // Zusätzliche Methoden für Brucheingabe

        /// Nimmt Benutzereingaben für einen Bruch entgegen.
        public Bruchrechner BruchEingabe(string nachricht)
        {
            Console.Write(nachricht);
            string[] eingabe = Console.ReadLine().Split('/');
            int zähler = int.Parse(eingabe[0]);
            int nenner = int.Parse(eingabe[1]);
            return new Bruchrechner(zähler, nenner);
        }

        public override string ToString()
        {
            return $"{zähler}/{nenner}";
        }
    }

    public class Bruchrechner
    {
        //public int Zähler { get; }
        //public int Nenner { get; }
        public int Zähler, Nenner;
        public Bruchrechner(int zähler, int nenner)
        {
            int ggT = GGT(zähler, nenner);
            Zähler = zähler / ggT;
            Nenner = nenner / ggT;
        }

        private int GGT(int a, int b)
        {
            return b == 0 ? a : GGT(b, a % b);
        }

        public override string ToString()
        {
            return $"{Zähler}/{Nenner}";
        }
    }
}
