﻿namespace Block_5_Task_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            textzaehler1 = new TextBox();
            textnenner1 = new TextBox();
            textzaehler2 = new TextBox();
            textnenner2 = new TextBox();
            textzaehlerErg = new TextBox();
            textnennerErg = new TextBox();
            comboBox1 = new ComboBox();
            imageList1 = new ImageList(components);
            b_calc = new Button();
            textBox1 = new TextBox();
            textKurzZ = new TextBox();
            textKurzN = new TextBox();
            textSpecialZ = new TextBox();
            textSpezialN = new TextBox();
            button1 = new Button();
            comboBox2 = new ComboBox();
            textSpZähler = new TextBox();
            textSpNenner = new TextBox();
            textPotenz = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            SuspendLayout();
            // 
            // textzaehler1
            // 
            textzaehler1.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textzaehler1.Location = new Point(19, 12);
            textzaehler1.Multiline = true;
            textzaehler1.Name = "textzaehler1";
            textzaehler1.Size = new Size(75, 73);
            textzaehler1.TabIndex = 0;
            // 
            // textnenner1
            // 
            textnenner1.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textnenner1.Location = new Point(19, 134);
            textnenner1.Multiline = true;
            textnenner1.Name = "textnenner1";
            textnenner1.Size = new Size(75, 73);
            textnenner1.TabIndex = 10;
            // 
            // textzaehler2
            // 
            textzaehler2.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textzaehler2.Location = new Point(195, 12);
            textzaehler2.Multiline = true;
            textzaehler2.Name = "textzaehler2";
            textzaehler2.Size = new Size(75, 73);
            textzaehler2.TabIndex = 11;
            // 
            // textnenner2
            // 
            textnenner2.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textnenner2.Location = new Point(195, 134);
            textnenner2.Multiline = true;
            textnenner2.Name = "textnenner2";
            textnenner2.Size = new Size(75, 73);
            textnenner2.TabIndex = 12;
            // 
            // textzaehlerErg
            // 
            textzaehlerErg.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textzaehlerErg.Location = new Point(377, 134);
            textzaehlerErg.Multiline = true;
            textzaehlerErg.Name = "textzaehlerErg";
            textzaehlerErg.Size = new Size(75, 73);
            textzaehlerErg.TabIndex = 13;
            // 
            // textnennerErg
            // 
            textnennerErg.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textnennerErg.Location = new Point(377, 12);
            textnennerErg.Multiline = true;
            textnennerErg.Name = "textnennerErg";
            textnennerErg.Size = new Size(75, 73);
            textnennerErg.TabIndex = 14;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold);
            comboBox1.FormattingEnabled = true;
            comboBox1.IntegralHeight = false;
            comboBox1.Items.AddRange(new object[] { "+", "-", "*", "/" });
            comboBox1.Location = new Point(115, 86);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(62, 45);
            comboBox1.TabIndex = 15;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "433a87bc7ed2c9bafcb1b8fe8f08f88d.jpg");
            // 
            // b_calc
            // 
            b_calc.Location = new Point(286, 86);
            b_calc.Name = "b_calc";
            b_calc.Size = new Size(75, 53);
            b_calc.TabIndex = 16;
            b_calc.Text = "=";
            b_calc.UseVisualStyleBackColor = true;
            b_calc.Click += b_calc_Click;
            // 
            // textBox1
            // 
            textBox1.ForeColor = Color.Red;
            textBox1.Location = new Point(68, 213);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(152, 23);
            textBox1.TabIndex = 17;
            // 
            // textKurzZ
            // 
            textKurzZ.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textKurzZ.Location = new Point(553, 12);
            textKurzZ.Multiline = true;
            textKurzZ.Name = "textKurzZ";
            textKurzZ.Size = new Size(75, 73);
            textKurzZ.TabIndex = 18;
            // 
            // textKurzN
            // 
            textKurzN.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textKurzN.Location = new Point(553, 134);
            textKurzN.Multiline = true;
            textKurzN.Name = "textKurzN";
            textKurzN.Size = new Size(75, 73);
            textKurzN.TabIndex = 19;
            // 
            // textSpecialZ
            // 
            textSpecialZ.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textSpecialZ.Location = new Point(164, 277);
            textSpecialZ.Multiline = true;
            textSpecialZ.Name = "textSpecialZ";
            textSpecialZ.Size = new Size(75, 73);
            textSpecialZ.TabIndex = 20;
            // 
            // textSpezialN
            // 
            textSpezialN.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textSpezialN.Location = new Point(164, 410);
            textSpezialN.Multiline = true;
            textSpezialN.Name = "textSpezialN";
            textSpezialN.Size = new Size(75, 73);
            textSpezialN.TabIndex = 21;
            // 
            // button1
            // 
            button1.Location = new Point(263, 356);
            button1.Name = "button1";
            button1.Size = new Size(75, 53);
            button1.TabIndex = 23;
            button1.Text = "=";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold);
            comboBox2.FormattingEnabled = true;
            comboBox2.IntegralHeight = false;
            comboBox2.Items.AddRange(new object[] { "√", "x^y" });
            comboBox2.Location = new Point(68, 354);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(62, 45);
            comboBox2.TabIndex = 24;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // textSpZähler
            // 
            textSpZähler.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textSpZähler.Location = new Point(364, 277);
            textSpZähler.Multiline = true;
            textSpZähler.Name = "textSpZähler";
            textSpZähler.Size = new Size(75, 73);
            textSpZähler.TabIndex = 25;
            // 
            // textSpNenner
            // 
            textSpNenner.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            textSpNenner.Location = new Point(364, 410);
            textSpNenner.Multiline = true;
            textSpNenner.Name = "textSpNenner";
            textSpNenner.Size = new Size(75, 73);
            textSpNenner.TabIndex = 26;
            // 
            // textPotenz
            // 
            textPotenz.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textPotenz.Location = new Point(245, 277);
            textPotenz.Multiline = true;
            textPotenz.Name = "textPotenz";
            textPotenz.Size = new Size(45, 40);
            textPotenz.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(367, 105);
            label1.Name = "label1";
            label1.Size = new Size(97, 15);
            label1.TabIndex = 28;
            label1.Text = "__________________";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(541, 105);
            label2.Name = "label2";
            label2.Size = new Size(97, 15);
            label2.TabIndex = 29;
            label2.Text = "__________________";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(355, 375);
            label3.Name = "label3";
            label3.Size = new Size(97, 15);
            label3.TabIndex = 30;
            label3.Text = "__________________";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(151, 375);
            label4.Name = "label4";
            label4.Size = new Size(97, 15);
            label4.TabIndex = 31;
            label4.Text = "__________________";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(183, 105);
            label5.Name = "label5";
            label5.Size = new Size(97, 15);
            label5.TabIndex = 32;
            label5.Text = "__________________";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(12, 105);
            label6.Name = "label6";
            label6.Size = new Size(97, 15);
            label6.TabIndex = 33;
            label6.Text = "__________________";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(483, 94);
            label7.Name = "label7";
            label7.Size = new Size(43, 45);
            label7.TabIndex = 34;
            label7.Text = "=";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(649, 502);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textPotenz);
            Controls.Add(textSpNenner);
            Controls.Add(textSpZähler);
            Controls.Add(comboBox2);
            Controls.Add(button1);
            Controls.Add(textSpezialN);
            Controls.Add(textSpecialZ);
            Controls.Add(textKurzN);
            Controls.Add(textKurzZ);
            Controls.Add(textBox1);
            Controls.Add(b_calc);
            Controls.Add(comboBox1);
            Controls.Add(textnennerErg);
            Controls.Add(textzaehlerErg);
            Controls.Add(textnenner2);
            Controls.Add(textzaehler2);
            Controls.Add(textnenner1);
            Controls.Add(textzaehler1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textzaehler1;
        private TextBox textnenner1;
        private TextBox textzaehler2;
        private TextBox textnenner2;
        private TextBox textzaehlerErg;
        private TextBox textnennerErg;
        private ComboBox comboBox1;
        private ImageList imageList1;
        private Button b_calc;
        private TextBox textBox1;
        private TextBox textKurzZ;
        private TextBox textKurzN;
        private TextBox textSpecialZ;
        private TextBox textSpezialN;
        private Button button1;
        private ComboBox comboBox2;
        private TextBox textSpZähler;
        private TextBox textSpNenner;
        private TextBox textPotenz;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
    }
}
