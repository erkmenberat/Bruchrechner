using Program_Block_4_6;
using System.Drawing;
using System.Runtime.Intrinsics.X86;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace Block_5_Task_2
{
    public partial class Form1 : Form
    {
        double nenner, z�hler, nenner2, z�hler2, resultnenner, resultz�hler;// variablen damit man �berhaupt zahlen einspeichern kann
        double SpezialZ�hler, SpezialNenner, SpezialResult; // variablen damit man �berhaupt zahlen einspeichern kann 
        public Form1()
        {
            InitializeComponent();
        }
        int op;  // varibalen f�rs Operatoren 
        int OP; // 


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //Bruchrechner b1, Bruchrechner b2)
        {
            op = comboBox1.SelectedIndex; // damit wir von den Box den Index als Operator benutzten k�nnen 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void b_calc_Click(object sender, EventArgs e) // das ist button um rechnen und auszugeben (=)
        {
            z�hler = Convert.ToDouble(textzaehler1.Text);
            nenner = Convert.ToDouble(textnenner1.Text);
            z�hler2 = Convert.ToDouble(textzaehler2.Text);
            nenner2 = Convert.ToDouble(textnenner2.Text);   // hier wird alles konvertiert zu double damit wir mit sie rechnen k�nnen
            switch (op) // operatoren auswahl von user 
            {
                case 0: // +
                    resultz�hler = z�hler * nenner2 + z�hler2 * nenner; //
                    resultnenner = nenner * nenner2;                    // das ist die formel damit wir br�che addieren k�nnen 
                    break;
                case 1:
                    resultz�hler = z�hler * nenner2 - z�hler2 * nenner;
                    resultnenner = nenner * nenner2;                    // formel f�r Subtraktion
                    break;
                case 2:
                    resultz�hler = z�hler * z�hler2;
                    resultnenner = nenner * nenner2;        // formel f�r Multiplikation 
                    break;
                case 3:
                    string ma = "Fehler: Division durch Null"; // ganz kleine if abfrage damit wenn der user 0 eingibt bewusst wird dass, das nicht m�glich ist 
                    if (z�hler2 == 0)
                        textBox1.Text = ma;

                    resultz�hler = z�hler * nenner2;
                    resultnenner = nenner * z�hler2; // Divisions formel 
                    break;
            }
            double kurzz, kurzn; // zwei variblen um z�hler und nenner zu k�rzen 
            textzaehlerErg.Text = resultz�hler.ToString();
            textnennerErg.Text = resultnenner.ToString(); // hier wird ergebnis ausgegeben 

            double ggT = GGT(resultz�hler, resultnenner); // K�rzungsformel
            kurzz = resultz�hler / ggT;
            kurzn = resultnenner / ggT;

            textKurzZ.Text = kurzz.ToString();
            textKurzN.Text = kurzn.ToString(); // Ausprinten von gek�rzten Zahlen 

        }
        private double GGT(double a, double b)  // das ist der GGT formel
        {
            double h;

            do
            {
                h = a % b;
                a = b;
                b = h;
            } while (b != 0);

            return a;
        }                                       // bis hier ist ggt formel 

        private void button1_Click(object sender, EventArgs e) // das ist button um rechnen und auszugeben (=)
        {
            SpezialZ�hler = Convert.ToInt32(textSpecialZ.Text); //
            SpezialNenner = Convert.ToInt32(textSpezialN.Text); // damit wir mit dem Zahlen auch rechnen k�nnen m�ssen wir sie zu intenger umwandeln

            switch (OP) // Operatoren auswahl von user 
            {
                case 0: // Wurzelziehen
                    double zwischenergz = (double)Math.Sqrt(SpezialZ�hler);
                    double zwischenergn = (double)Math.Sqrt(SpezialNenner); // Nenner und Z�hler wurden Gewurzelt 
                    double ggT = GGT(zwischenergz, zwischenergn); // GGT wird herausgefunden
                    double kurzz = zwischenergz / ggT; //  z�hler wird gek�rzt 
                    double kurzn = zwischenergn / ggT; //  nenner wird gek�rzt 
                    textSpZ�hler.Text = kurzz.ToString(); 
                    textSpNenner.Text = kurzn.ToString(); // wird ausgegeben 
                    break;
                case 1: // Potenzieren 
                    double exponent; // ein variable f�r den exponent wird erstellt 
                    exponent = Convert.ToDouble(textPotenz.Text); // der variable wird intialisiert indem wir den inhalt von den textbox hinzuf�gen
                    zwischenergz = (double)Math.Pow(SpezialZ�hler, exponent); // z�hler wird ausgerechnet
                    zwischenergn = (double)Math.Pow(SpezialNenner, exponent); // nenner wird ausgerechnet
                    ggT = GGT(zwischenergz, zwischenergn); // GGT wird berechnet 
                    kurzz = zwischenergz / ggT; //  z�hler wird gek�rzt 
                    kurzn = zwischenergn / ggT; //  nenner wird gek�rzt 
                    textSpZ�hler.Text = kurzz.ToString(); // 
                    textSpNenner.Text = kurzn.ToString(); // es wird ausgegeben 
                    break;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            OP = comboBox2.SelectedIndex; // das ist dazu da damit wir von den Box den index als Operatorauswahl benutzten k�nnen 
        }

    }
}

// Bedienungsanleitung f�r den Bruchrechner:

// Allgemein:
// - Verwenden Sie die Textboxen, um Z�hler und Nenner der Br�che einzugeben.
// - W�hlen Sie in den Dropdown-Men�s den gew�nschten Operator aus.

// Bruchrechner f�r normale Br�che:
// - W�hlen Sie den Operator (+, -, x, �) aus dem Dropdown-Men�.
// - Geben Sie Z�hler und Nenner f�r beide Br�che ein.
// - Klicken Sie auf den Berechnen-Button (=), um das Ergebnis zu erhalten.
// - Das Ergebnis wird als ungek�rzter Bruch angezeigt.
// - Das Ergebnis wird zus�tzlich als gek�rzter Bruch angezeigt.

// Spezialfunktionen f�r einzelne Zahlen:
// - W�hlen Sie den Operator (Wurzelziehen, Potenzieren) aus dem Dropdown-Men�.
// - Geben Sie die gew�nschte Zahl ein.
// - Bei Potenzieren geben Sie zus�tzlich den Exponenten ein.
// - Klicken Sie auf den Berechnen-Button, um das Ergebnis zu erhalten.
// - Das Ergebnis wird als ungek�rzter Bruch angezeigt.
// - Das Ergebnis wird zus�tzlich als gek�rzter Bruch angezeigt.
